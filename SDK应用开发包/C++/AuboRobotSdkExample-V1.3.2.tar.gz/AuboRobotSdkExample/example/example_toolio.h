#ifndef EXAMPLE_TOOLIO_H
#define EXAMPLE_TOOLIO_H

class Example_ToolIO
{
public:
    static void demo();

};

#endif // EXAMPLE_TOOLIO_H
