#ifndef INTERFACETEST_H
#define INTERFACETEST_H

#include "AuboRobotMetaType.h"
#include "serviceinterface.h"



class InterfaceTest
{
public:
    InterfaceTest();

    static void test();
};

#endif // INTERFACETEST_H
